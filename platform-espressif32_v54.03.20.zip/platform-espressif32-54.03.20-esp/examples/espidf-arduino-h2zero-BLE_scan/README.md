# Arduino_IDF_BLE_scan example using 3rd party NimBLE stack

BLE scan example, using the great h2zero NimBLE implementation. The needed NimBLE lib is loaded via the IDF component manager -> `idf_component.yml`.
Mandantory not to forget to switch Arduino included BLE libs.
Done in `sdkconfig.defaults`

Thx @h2zero for the great BLE library.
